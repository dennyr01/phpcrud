<?php
$settings['driver'] = 'sqlsrv';
