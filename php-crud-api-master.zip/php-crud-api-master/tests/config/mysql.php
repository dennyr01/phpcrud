<?php
$settings['driver'] = 'mysql';
