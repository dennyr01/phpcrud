<?php
$settings['driver'] = 'pgsql';
$settings['address'] = '127.0.0.1';
